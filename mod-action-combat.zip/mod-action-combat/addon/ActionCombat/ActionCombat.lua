-- ActionCombat client addon (WoW 3.3.5a) for mod-action-combat
-- Sends button presses to the server and draws the stamina bar / combat feedback.

local PREFIX = "ACM"
local AC = CreateFrame("Frame", "ActionCombatFrame", UIParent)
ActionCombat = AC

-- Key binding labels (Esc > Key Bindings > ActionCombat)
BINDING_HEADER_ACTIONCOMBAT = "Action Combat"
BINDING_NAME_ACM_LIGHT = "Light attack (tap for combo)"
BINDING_NAME_ACM_HEAVY = "Heavy attack (hold to charge)"
BINDING_NAME_ACM_DODGE = "Dodge roll / backstep"
BINDING_NAME_ACM_GUARD = "Guard (hold) / perfect parry (tap on hit)"

------------------------------------------------------------------------ comms

local function Send(msg)
    SendAddonMessage(PREFIX, msg, "WHISPER", UnitName("player"))
end

local function Facing()
    local f = GetPlayerFacing and GetPlayerFacing()
    return f and string.format("%.3f", f) or ""
end

------------------------------------------------------------------------ movement tracking (for 8-way roll)

local move = { F = false, B = false, L = false, R = false }
local function hook(fn, key, state)
    if _G[fn] then hooksecurefunc(fn, function() move[key] = state end) end
end
hook("MoveForwardStart", "F", true);   hook("MoveForwardStop", "F", false)
hook("MoveBackwardStart", "B", true);  hook("MoveBackwardStop", "B", false)
hook("StrafeLeftStart", "L", true);    hook("StrafeLeftStop", "L", false)
hook("StrafeRightStart", "R", true);   hook("StrafeRightStop", "R", false)

local function MoveDir()
    local v = (move.F and not move.B) and "F" or (move.B and not move.F) and "B" or ""
    local h = (move.L and not move.R) and "L" or (move.R and not move.L) and "R" or ""
    local d = v .. h
    return d ~= "" and d or "N"
end

------------------------------------------------------------------------ UI: stamina bar

local holder = CreateFrame("Frame", "ActionCombatStamina", UIParent)
holder:SetSize(260, 10)
holder:SetPoint("BOTTOM", UIParent, "BOTTOM", 0, 190)
holder:Hide()

local bg = holder:CreateTexture(nil, "BACKGROUND")
bg:SetAllPoints()
bg:SetTexture(0, 0, 0, 0.55)

local function MakeBar(level, r, g, b, a)
    local sb = CreateFrame("StatusBar", nil, holder)
    sb:SetAllPoints()
    sb:SetFrameLevel(holder:GetFrameLevel() + level)
    sb:SetStatusBarTexture("Interface\\TargetingFrame\\UI-StatusBar")
    sb:SetStatusBarColor(r, g, b, a)
    sb:SetMinMaxValues(0, 100)
    sb:SetValue(100)
    return sb
end
-- "ghost" bar that lags behind, like Elden Ring's chip damage
local ghost = MakeBar(1, 0.9, 0.8, 0.3, 0.6)
local bar = MakeBar(2, 0.35, 0.85, 0.35, 1)

local border = CreateFrame("Frame", nil, holder)
border:SetFrameLevel(holder:GetFrameLevel() + 3)
border:SetPoint("TOPLEFT", -3, 3)
border:SetPoint("BOTTOMRIGHT", 3, -3)
border:SetBackdrop({ edgeFile = "Interface\\Tooltips\\UI-Tooltip-Border", edgeSize = 10 })
border:SetBackdropBorderColor(0.6, 0.6, 0.6, 0.9)

-- heavy-attack charge bar
local charge = CreateFrame("StatusBar", nil, UIParent)
charge:SetSize(120, 5)
charge:SetPoint("TOP", holder, "BOTTOM", 0, -6)
charge:SetStatusBarTexture("Interface\\TargetingFrame\\UI-StatusBar")
charge:SetStatusBarColor(1, 0.55, 0.1)
charge:SetMinMaxValues(0, 1)
charge:Hide()
local chargeBg = charge:CreateTexture(nil, "BACKGROUND")
chargeBg:SetAllPoints()
chargeBg:SetTexture(0, 0, 0, 0.5)

-- guard icon
local guard = border:CreateTexture(nil, "OVERLAY")
guard:SetSize(18, 18)
guard:SetPoint("RIGHT", holder, "LEFT", -6, 0)
guard:SetTexture("Interface\\Icons\\INV_Shield_06")
guard:Hide()

-- big center feedback text
local feedback = UIParent:CreateFontString(nil, "OVERLAY")
feedback:SetFont("Fonts\\MORPHEUS.ttf", 34, "OUTLINE")
feedback:SetPoint("CENTER", UIParent, "CENTER", 0, 140)
feedback:SetAlpha(0)

-- full-screen flash for parries / guard breaks
local flash = UIParent:CreateTexture(nil, "BACKGROUND")
flash:SetAllPoints(UIParent)
flash:SetTexture(1, 1, 1)
flash:SetBlendMode("ADD")
flash:SetAlpha(0)

local feedbackT, flashT = 0, 0
local function Feedback(text, r, g, b, doFlash)
    feedback:SetText(text)
    feedback:SetTextColor(r, g, b)
    feedbackT = 0.9
    if doFlash then
        flash:SetVertexColor(r, g, b)
        flashT = 0.25
    end
end

------------------------------------------------------------------------ state

local stamina, staminaMax, ghostVal = 100, 100, 100
local heavyDown, heavyStart = false, 0
local MAX_CHARGE = 1.5

local EVENTS = {
    PARRY      = function() Feedback("PARRY", 1, 0.85, 0.3, true); PlaySoundFile("Sound\\Interface\\iAbilitiesTurnOn.wav") end,
    STAGGER    = function() Feedback("STAGGER", 1, 0.5, 0.2) end,
    RIPOSTE    = function() Feedback("CRITICAL", 1, 0.2, 0.2, true) end,
    EVADE      = function() Feedback("EVADED", 0.6, 0.9, 1) end,
    GUARDBREAK = function() Feedback("GUARD BROKEN", 0.9, 0.2, 0.2, true) end,
    NOSTAM     = function() Feedback("Out of stamina", 0.7, 0.7, 0.7); UIFrameFlash(holder, 0.1, 0.1, 0.4, true, 0, 0) end,
    HEAVY_FULL = function() Feedback("!", 1, 0.55, 0.1) end,
    GUARD_ON   = function() guard:Show() end,
    GUARD_OFF  = function() guard:Hide() end,
    ROLL       = function() guard:Hide() end,
    BACKSTEP   = function() guard:Hide() end,
}

------------------------------------------------------------------------ bindings (called from Bindings.xml)

function ActionCombat_Light()
    Send("L " .. Facing())
end

function ActionCombat_Heavy(keystate)
    if keystate == "down" then
        heavyDown, heavyStart = true, GetTime()
        charge:SetValue(0); charge:Show()
        Send("HS")
    else
        if heavyDown then Send("HR " .. Facing()) end
        heavyDown = false
        charge:Hide()
    end
end

function ActionCombat_Dodge()
    Send("D " .. MoveDir() .. " " .. Facing())
end

function ActionCombat_Guard(keystate)
    Send(keystate == "down" and "GS" or "GE")
end

------------------------------------------------------------------------ events / update

AC:RegisterEvent("PLAYER_ENTERING_WORLD")
AC:RegisterEvent("CHAT_MSG_ADDON")
AC:SetScript("OnEvent", function(_, event, prefix, msg)
    if event == "PLAYER_ENTERING_WORLD" then
        Send("HELLO")
    elseif event == "CHAT_MSG_ADDON" and prefix == PREFIX then
        local cmd, a, b = strsplit(" ", msg)
        if cmd == "S" then
            stamina, staminaMax = tonumber(a) or stamina, tonumber(b) or staminaMax
            bar:SetMinMaxValues(0, staminaMax); ghost:SetMinMaxValues(0, staminaMax)
            bar:SetValue(stamina)
            if stamina > ghostVal then ghostVal = stamina end
        elseif cmd == "V" then
            holder:Show()
        elseif cmd == "E" and EVENTS[a] then
            EVENTS[a]()
        end
    end
end)

AC:SetScript("OnUpdate", function(_, elapsed)
    -- ghost bar drains toward real value
    if ghostVal > stamina then
        ghostVal = math.max(stamina, ghostVal - staminaMax * 0.8 * elapsed)
    end
    ghost:SetValue(ghostVal)

    -- hide bar when full and out of combat, like modern action games
    if holder:IsShown() then
        local full = stamina >= staminaMax and not UnitAffectingCombat("player")
        holder:SetAlpha(full and math.max(0, holder:GetAlpha() - elapsed) or 1)
    end

    if heavyDown then
        local t = math.min(1, (GetTime() - heavyStart) / MAX_CHARGE)
        charge:SetValue(t)
        charge:SetStatusBarColor(1, 0.55 + 0.45 * t, 0.1 + 0.6 * t)
    end

    if feedbackT > 0 then
        feedbackT = feedbackT - elapsed
        feedback:SetAlpha(math.min(1, feedbackT * 3))
    end
    if flashT > 0 then
        flashT = flashT - elapsed
        flash:SetAlpha(math.max(0, flashT))
    end
end)

SLASH_ACTIONCOMBAT1 = "/acm"
SlashCmdList.ACTIONCOMBAT = function()
    DEFAULT_CHAT_FRAME:AddMessage("|cff4fc3f7Action Combat|r: set keys in Esc > Key Bindings > Action Combat.")
    DEFAULT_CHAT_FRAME:AddMessage("Suggested: Light = Left mouse + Shift or 1, Heavy = 2 (hold), Dodge = Space-alt / Mouse4, Guard = Mouse5 (hold).")
    Send("HELLO")
end
