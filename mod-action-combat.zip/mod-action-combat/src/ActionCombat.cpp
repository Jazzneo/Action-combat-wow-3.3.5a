/*
 * mod-action-combat — Zelda / Elden Ring style action combat for AzerothCore (3.3.5a)
 *
 * Features
 *   - Stamina bar (server-authoritative, synced to the ActionCombat client addon)
 *   - Dodge roll in any of 8 directions with invulnerability frames (backstep when idle)
 *   - Light attack combo (3 hits, cone cleave, rising damage)
 *   - Charged heavy attack (hold to charge, bigger cone, big poise damage)
 *   - Guard (reduces damage, drains stamina, guard break when empty)
 *   - Perfect parry (press guard just before a hit: negate it and stagger the attacker)
 *   - Enemy poise: enough hits stagger an enemy; the next hit is a critical "riposte"
 *
 * Transport: the client addon sends SendAddonMessage("ACM", "<cmd>", "WHISPER", <self>).
 * The whisper is swallowed by OnPlayerCanUseChat and the command is queued; it is executed
 * in OnPlayerUpdate (map thread) so all combat logic runs where unit state is safe to touch.
 */

#include "ActionCombat.h"

#include "CellImpl.h"
#include "Chat.h"
#include "Config.h"
#include "Creature.h"
#include "GridNotifiers.h"
#include "GridNotifiersImpl.h"
#include "Player.h"
#include "ScriptMgr.h"
#include "SpellInfo.h"
#include "Timer.h"
#include "WorldPacket.h"

#include <algorithm>
#include <cmath>
#include <sstream>

namespace ActionCombat
{
    Config Cfg;

    // Context of the action swing currently being resolved on this thread.
    // AttackerStateUpdate() calls back into ModifyMeleeDamage synchronously, so a thread_local
    // is enough to know "this melee hit came from a light/heavy attack" (map updates can be
    // multi-threaded, hence thread_local rather than a plain global).
    struct SwingContext
    {
        ObjectGuid attacker;
        float damageMult = 1.0f;
        float poiseDamage = 0.0f;
    };
    thread_local SwingContext const* tl_swing = nullptr;

    // ------------------------------------------------------------------ config

    void LoadConfig()
    {
        Cfg.enabled             = sConfigMgr->GetOption<bool>("ActionCombat.Enable", true);
        Cfg.announce            = sConfigMgr->GetOption<bool>("ActionCombat.Announce", true);

        Cfg.staminaMax          = sConfigMgr->GetOption<float>("ActionCombat.Stamina.Max", 100.0f);
        Cfg.staminaRegen        = sConfigMgr->GetOption<float>("ActionCombat.Stamina.RegenPerSec", 35.0f);
        Cfg.staminaRegenDelay   = sConfigMgr->GetOption<uint32>("ActionCombat.Stamina.RegenDelayMs", 900);
        Cfg.guardRegenPct       = sConfigMgr->GetOption<float>("ActionCombat.Stamina.GuardRegenPct", 40.0f);

        Cfg.dodgeCost           = sConfigMgr->GetOption<float>("ActionCombat.Dodge.Cost", 25.0f);
        Cfg.dodgeCooldown       = sConfigMgr->GetOption<uint32>("ActionCombat.Dodge.CooldownMs", 450);
        Cfg.dodgeIFrames        = sConfigMgr->GetOption<uint32>("ActionCombat.Dodge.IFramesMs", 400);
        Cfg.dodgeSpeedXY        = sConfigMgr->GetOption<float>("ActionCombat.Dodge.SpeedXY", 16.0f);
        Cfg.dodgeSpeedZ         = sConfigMgr->GetOption<float>("ActionCombat.Dodge.SpeedZ", 3.0f);
        Cfg.backstepSpeedXY     = sConfigMgr->GetOption<float>("ActionCombat.Dodge.BackstepSpeedXY", 10.0f);
        Cfg.backstepIFrames     = sConfigMgr->GetOption<uint32>("ActionCombat.Dodge.BackstepIFramesMs", 250);

        Cfg.lightCost           = sConfigMgr->GetOption<float>("ActionCombat.Light.Cost", 12.0f);
        Cfg.lightCooldown       = sConfigMgr->GetOption<uint32>("ActionCombat.Light.CooldownMs", 550);
        Cfg.lightRange          = sConfigMgr->GetOption<float>("ActionCombat.Light.Range", 5.0f);
        Cfg.lightArcDeg         = sConfigMgr->GetOption<float>("ActionCombat.Light.ArcDegrees", 100.0f);
        Cfg.lightFinisherArcDeg = sConfigMgr->GetOption<float>("ActionCombat.Light.FinisherArcDegrees", 200.0f);
        Cfg.lightPoise          = sConfigMgr->GetOption<float>("ActionCombat.Light.Poise", 12.0f);
        Cfg.comboWindow         = sConfigMgr->GetOption<uint32>("ActionCombat.Light.ComboWindowMs", 1100);
        Cfg.comboMult[0]        = sConfigMgr->GetOption<float>("ActionCombat.Light.Combo1Mult", 1.0f);
        Cfg.comboMult[1]        = sConfigMgr->GetOption<float>("ActionCombat.Light.Combo2Mult", 1.15f);
        Cfg.comboMult[2]        = sConfigMgr->GetOption<float>("ActionCombat.Light.Combo3Mult", 1.5f);

        Cfg.heavyCost           = sConfigMgr->GetOption<float>("ActionCombat.Heavy.Cost", 30.0f);
        Cfg.heavyMinCharge      = sConfigMgr->GetOption<uint32>("ActionCombat.Heavy.MinChargeMs", 350);
        Cfg.heavyMaxCharge      = sConfigMgr->GetOption<uint32>("ActionCombat.Heavy.MaxChargeMs", 1500);
        Cfg.heavyCooldown       = sConfigMgr->GetOption<uint32>("ActionCombat.Heavy.CooldownMs", 900);
        Cfg.heavyRange          = sConfigMgr->GetOption<float>("ActionCombat.Heavy.Range", 6.0f);
        Cfg.heavyArcDeg         = sConfigMgr->GetOption<float>("ActionCombat.Heavy.ArcDegrees", 140.0f);
        Cfg.heavyMinMult        = sConfigMgr->GetOption<float>("ActionCombat.Heavy.MinMult", 1.6f);
        Cfg.heavyMaxMult        = sConfigMgr->GetOption<float>("ActionCombat.Heavy.MaxMult", 2.8f);
        Cfg.heavyPoise          = sConfigMgr->GetOption<float>("ActionCombat.Heavy.Poise", 40.0f);

        Cfg.maxTargets          = sConfigMgr->GetOption<uint32>("ActionCombat.Attack.MaxTargets", 5);
        Cfg.autoAttackPct       = sConfigMgr->GetOption<float>("ActionCombat.AutoAttack.DamagePct", 30.0f);

        Cfg.guardReductionPct   = sConfigMgr->GetOption<float>("ActionCombat.Guard.DamageReductionPct", 70.0f);
        Cfg.guardStaminaPerDmgPct = sConfigMgr->GetOption<float>("ActionCombat.Guard.StaminaPerHpPct", 2.0f);
        Cfg.guardMinStaminaHit  = sConfigMgr->GetOption<float>("ActionCombat.Guard.MinStaminaPerHit", 8.0f);
        Cfg.guardSpellsToo      = sConfigMgr->GetOption<bool>("ActionCombat.Guard.BlocksSpells", false);
        Cfg.parryWindow         = sConfigMgr->GetOption<uint32>("ActionCombat.Parry.WindowMs", 220);
        Cfg.parryPoise          = sConfigMgr->GetOption<float>("ActionCombat.Parry.Poise", 100.0f);

        Cfg.staggerSpell        = sConfigMgr->GetOption<uint32>("ActionCombat.Stagger.SpellId", 56);
        Cfg.poiseNormal         = sConfigMgr->GetOption<float>("ActionCombat.Poise.Normal", 40.0f);
        Cfg.poiseElite          = sConfigMgr->GetOption<float>("ActionCombat.Poise.Elite", 120.0f);
        Cfg.poiseBoss           = sConfigMgr->GetOption<float>("ActionCombat.Poise.Boss", 0.0f);
        Cfg.poiseRegenDelay     = sConfigMgr->GetOption<uint32>("ActionCombat.Poise.ResetAfterMs", 4000);
        Cfg.riposteWindow       = sConfigMgr->GetOption<uint32>("ActionCombat.Riposte.WindowMs", 3000);
        Cfg.riposteMult         = sConfigMgr->GetOption<float>("ActionCombat.Riposte.Mult", 2.5f);
    }

    // ------------------------------------------------------------------ helpers

    PlayerState* GetState(Player* player)
    {
        return player->CustomData.GetDefault<PlayerState>("ActionCombat");
    }

    CreatureState* GetState(Creature* creature)
    {
        return creature->CustomData.GetDefault<CreatureState>("ActionCombat");
    }

    void SendToClient(Player* player, std::string const& msg)
    {
        WorldPacket data;
        ChatHandler::BuildChatPacket(data, CHAT_MSG_WHISPER, LANG_ADDON, player, player, std::string(ADDON_PREFIX) + "\t" + msg);
        player->SendDirectMessage(&data);
    }

    void SendEvent(Player* player, char const* evt)
    {
        SendToClient(player, std::string("E ") + evt);
    }

    void SendStamina(Player* player, PlayerState* st)
    {
        std::ostringstream ss;
        ss << "S " << int32(st->stamina) << ' ' << int32(Cfg.staminaMax);
        SendToClient(player, ss.str());
        st->lastSentStamina = int32(st->stamina);
    }

    bool SpendStamina(Player* player, PlayerState* st, float cost, uint32 now)
    {
        // Elden Ring rule: you can start an action as long as you have *any* stamina left,
        // but the bar can't go below zero.
        if (st->stamina <= 0.0f)
        {
            SendEvent(player, "NOSTAM");
            return false;
        }
        st->stamina = std::max(0.0f, st->stamina - cost);
        st->lastSpend = now;
        SendStamina(player, st);
        return true;
    }

    bool CanAct(Player* player)
    {
        return player->IsAlive()
            && !player->IsMounted()
            && !player->GetVehicle()
            && !player->IsFlying()
            && !player->HasUnitState(UNIT_STATE_LOST_CONTROL)
            && !player->HasUnitFlag(UNIT_FLAG_PACIFIED)
            && !player->IsNonMeleeSpellCast(false);
    }

    float ClientFacing(Player* player, std::string const& arg)
    {
        // The client tells us where the camera/character is facing at the moment of the button
        // press (movement packets may lag a few ms behind). Accept it only if it is close to
        // what the server already believes, so a cheater can't hit things behind them freely.
        if (arg.empty())
            return player->GetOrientation();

        float f = std::strtof(arg.c_str(), nullptr);
        if (!std::isfinite(f))
            return player->GetOrientation();

        f = Position::NormalizeOrientation(f);
        float diff = std::fabs(Position::NormalizeOrientation(f - player->GetOrientation()));
        if (diff > float(M_PI))
            diff = 2.0f * float(M_PI) - diff;

        return diff <= float(M_PI) / 2.0f ? f : player->GetOrientation();
    }

    float PoiseFor(Creature* c)
    {
        if (c->isWorldBoss() || c->IsDungeonBoss())
            return Cfg.poiseBoss;
        if (c->isElite())
            return Cfg.poiseElite;
        return Cfg.poiseNormal;
    }

    void Stagger(Unit* target)
    {
        if (Cfg.staggerSpell)
            target->AddAura(Cfg.staggerSpell, target);
    }

    // Applies poise damage to a creature; returns true if it got staggered by this hit.
    bool ApplyPoise(Player* attacker, Creature* target, float poiseDamage, uint32 now)
    {
        float maxPoise = PoiseFor(target);
        if (maxPoise <= 0.0f || poiseDamage <= 0.0f)
            return false;

        CreatureState* cs = GetState(target);
        if (cs->lastPoiseHit && getMSTimeDiff(cs->lastPoiseHit, now) > Cfg.poiseRegenDelay)
            cs->poise = 0.0f;

        cs->lastPoiseHit = now;
        cs->poise += poiseDamage;

        if (cs->poise < maxPoise)
            return false;

        cs->poise = 0.0f;
        cs->riposteUntil = now + Cfg.riposteWindow;
        Stagger(target);
        SendEvent(attacker, "STAGGER");
        return true;
    }

    // ------------------------------------------------------------------ actions

    void DoSwing(Player* player, float facing, float range, float arcDeg, float mult, float poise)
    {
        player->SetOrientation(facing);

        std::list<Unit*> targets;
        Acore::AnyUnfriendlyUnitInObjectRangeCheck check(player, player, range + player->GetCombatReach());
        Acore::UnitListSearcher<Acore::AnyUnfriendlyUnitInObjectRangeCheck> searcher(player, targets, check);
        Cell::VisitObjects(player, searcher, range + player->GetCombatReach() + 5.0f);

        float arc = arcDeg * float(M_PI) / 180.0f;
        targets.remove_if([&](Unit* u)
        {
            return u == player
                || !player->isInFront(u, arc)
                || !player->IsValidAttackTarget(u)
                || !player->IsWithinLOSInMap(u)
                || player->GetDistance(u) > range + u->GetCombatReach();
        });

        // Closest targets first, capped
        targets.sort([&](Unit* a, Unit* b) { return player->GetDistance(a) < player->GetDistance(b); });
        if (targets.size() > Cfg.maxTargets)
            targets.resize(Cfg.maxTargets);

        if (targets.empty())
        {
            // whiff — still play the swing so it feels responsive
            player->HandleEmoteCommand(mult > Cfg.comboMult[2] ? EMOTE_ONESHOT_ATTACK2HTIGHT : EMOTE_ONESHOT_ATTACK1H);
            return;
        }

        SwingContext ctx;
        ctx.attacker = player->GetGUID();
        ctx.damageMult = mult;
        ctx.poiseDamage = poise;

        for (Unit* target : targets)
        {
            tl_swing = &ctx;
            player->AttackerStateUpdate(target, BASE_ATTACK, true);
            tl_swing = nullptr;
        }
    }

    void DoLight(Player* player, PlayerState* st, std::string const& arg, uint32 now)
    {
        if (st->nextLightAt && int32(now - st->nextLightAt) < 0)
            return;
        if (!SpendStamina(player, st, Cfg.lightCost, now))
            return;

        if (st->comboIndex > 0 && getMSTimeDiff(st->lastLight, now) > Cfg.comboWindow)
            st->comboIndex = 0;

        uint8 idx = st->comboIndex;
        bool finisher = idx == 2;
        DoSwing(player, ClientFacing(player, arg), Cfg.lightRange,
                finisher ? Cfg.lightFinisherArcDeg : Cfg.lightArcDeg,
                Cfg.comboMult[idx], Cfg.lightPoise * (finisher ? 1.5f : 1.0f));

        st->lastLight = now;
        st->comboIndex = uint8((idx + 1) % 3);
        st->nextLightAt = now + Cfg.lightCooldown;

        std::ostringstream ss;
        ss << "COMBO " << int32(idx + 1);
        SendEvent(player, ss.str().c_str());
    }

    void DoHeavyStart(PlayerState* st, uint32 now)
    {
        st->heavyChargeStart = now;
    }

    void DoHeavyRelease(Player* player, PlayerState* st, std::string const& arg, uint32 now)
    {
        if (!st->heavyChargeStart)
            return;

        uint32 charge = getMSTimeDiff(st->heavyChargeStart, now);
        st->heavyChargeStart = 0;

        if (charge < Cfg.heavyMinCharge)
        {
            SendEvent(player, "HEAVY_CANCEL");
            return;
        }
        if (st->nextHeavyAt && int32(now - st->nextHeavyAt) < 0)
            return;
        if (!SpendStamina(player, st, Cfg.heavyCost, now))
            return;

        float t = std::min(1.0f, float(charge - Cfg.heavyMinCharge) / float(std::max<uint32>(1, Cfg.heavyMaxCharge - Cfg.heavyMinCharge)));
        float mult = Cfg.heavyMinMult + (Cfg.heavyMaxMult - Cfg.heavyMinMult) * t;

        DoSwing(player, ClientFacing(player, arg), Cfg.heavyRange, Cfg.heavyArcDeg, mult, Cfg.heavyPoise * (1.0f + t));

        st->comboIndex = 0;
        st->nextHeavyAt = now + Cfg.heavyCooldown;
        st->nextLightAt = now + Cfg.lightCooldown;
        SendEvent(player, t >= 1.0f ? "HEAVY_FULL" : "HEAVY");
    }

    // dir: F, B, L, R, FL, FR, BL, BR, or N (no movement -> backstep)
    void DoDodge(Player* player, PlayerState* st, std::string const& dir, std::string const& facingArg, uint32 now)
    {
        if (st->nextDodgeAt && int32(now - st->nextDodgeAt) < 0)
            return;
        if (player->HasUnitState(UNIT_STATE_ROOT) || player->IsFalling() || player->IsInWater())
            return;
        if (!SpendStamina(player, st, Cfg.dodgeCost, now))
            return;

        float offset = 0.0f;
        bool backstep = false;
        if      (dir == "F")  offset = 0.0f;
        else if (dir == "B")  offset = float(M_PI);
        else if (dir == "L")  offset = float(M_PI) / 2.0f;
        else if (dir == "R")  offset = -float(M_PI) / 2.0f;
        else if (dir == "FL") offset = float(M_PI) / 4.0f;
        else if (dir == "FR") offset = -float(M_PI) / 4.0f;
        else if (dir == "BL") offset = 3.0f * float(M_PI) / 4.0f;
        else if (dir == "BR") offset = -3.0f * float(M_PI) / 4.0f;
        else { offset = float(M_PI); backstep = true; }

        float facing = ClientFacing(player, facingArg);
        float angle = Position::NormalizeOrientation(facing + offset);

        // KnockbackFrom pushes *away* from the given point, so put the point opposite to where we roll.
        float ox = player->GetPositionX() - std::cos(angle);
        float oy = player->GetPositionY() - std::sin(angle);
        player->KnockbackFrom(ox, oy, backstep ? Cfg.backstepSpeedXY : Cfg.dodgeSpeedXY, Cfg.dodgeSpeedZ);

        st->iframesUntil = now + (backstep ? Cfg.backstepIFrames : Cfg.dodgeIFrames);
        st->nextDodgeAt = now + Cfg.dodgeCooldown;
        st->comboIndex = 0;
        st->heavyChargeStart = 0;
        st->guarding = false;
        SendEvent(player, backstep ? "BACKSTEP" : "ROLL");
    }

    void DoGuard(Player* player, PlayerState* st, bool on, uint32 now)
    {
        if (on)
        {
            if (st->guarding)
                return;
            st->guarding = true;
            st->guardStart = now;
            st->parryUsed = false;
            player->HandleEmoteCommand(player->GetShield() ? EMOTE_ONESHOT_PARRY_SHIELD : EMOTE_ONESHOT_PARRY_UNARMED);
        }
        else
            st->guarding = false;
        SendEvent(player, on ? "GUARD_ON" : "GUARD_OFF");
    }

    void Execute(Player* player, PlayerState* st, std::string const& line, uint32 now)
    {
        std::istringstream in(line);
        std::string cmd, a1, a2;
        in >> cmd >> a1 >> a2;

        if (cmd == "HELLO")
        {
            st->addonPresent = true;
            SendStamina(player, st);
            SendToClient(player, "V 1");
            return;
        }

        bool needsAct = cmd == "L" || cmd == "HR" || cmd == "D" || cmd == "GS";
        if (needsAct && !CanAct(player))
            return;

        if      (cmd == "L")  DoLight(player, st, a1, now);
        else if (cmd == "HS") DoHeavyStart(st, now);
        else if (cmd == "HR") DoHeavyRelease(player, st, a1, now);
        else if (cmd == "D")  DoDodge(player, st, a1, a2, now);
        else if (cmd == "GS") DoGuard(player, st, true, now);
        else if (cmd == "GE") DoGuard(player, st, false, now);
    }

    // Shared logic for melee and direct spell damage taken by a player.
    // Returns true if the damage was fully negated.
    bool DefendPlayer(Player* victim, Unit* attacker, uint32& damage, bool isMelee)
    {
        PlayerState* st = GetState(victim);
        uint32 now = getMSTime();

        if (st->iframesUntil && int32(now - st->iframesUntil) < 0)
        {
            damage = 0;
            SendEvent(victim, "EVADE");
            return true;
        }

        if (!st->guarding || !attacker || attacker == victim)
            return false;
        if (!isMelee && !Cfg.guardSpellsToo)
            return false;
        if (!victim->HasInArc(float(M_PI), attacker))   // guard only covers the front
            return false;

        // Perfect parry
        if (isMelee && !st->parryUsed && getMSTimeDiff(st->guardStart, now) <= Cfg.parryWindow)
        {
            st->parryUsed = true;
            damage = 0;
            SendEvent(victim, "PARRY");
            if (Creature* c = attacker->ToCreature())
                ApplyPoise(victim, c, Cfg.parryPoise, now);
            return true;
        }

        // Regular guard: reduce damage, pay stamina
        float hpPct = victim->GetMaxHealth() ? 100.0f * float(damage) / float(victim->GetMaxHealth()) : 0.0f;
        float cost = std::max(Cfg.guardMinStaminaHit, hpPct * Cfg.guardStaminaPerDmgPct);
        st->stamina -= cost;
        st->lastSpend = now;

        if (st->stamina <= 0.0f)
        {
            st->stamina = 0.0f;
            st->guarding = false;
            Stagger(victim);
            SendEvent(victim, "GUARDBREAK");
            SendStamina(victim, st);
            return false; // full damage goes through on a guard break
        }

        damage = uint32(float(damage) * (100.0f - Cfg.guardReductionPct) / 100.0f);
        SendEvent(victim, "BLOCK");
        SendStamina(victim, st);
        return false;
    }
}

using namespace ActionCombat;

// ====================================================================== scripts

class ActionCombat_WorldScript : public WorldScript
{
public:
    ActionCombat_WorldScript() : WorldScript("ActionCombat_WorldScript", { WORLDHOOK_ON_AFTER_CONFIG_LOAD }) { }

    void OnAfterConfigLoad(bool /*reload*/) override
    {
        LoadConfig();
    }
};

class ActionCombat_PlayerScript : public PlayerScript
{
public:
    ActionCombat_PlayerScript() : PlayerScript("ActionCombat_PlayerScript", {
        PLAYERHOOK_ON_LOGIN,
        PLAYERHOOK_ON_UPDATE,
        PLAYERHOOK_CAN_PLAYER_USE_PRIVATE_CHAT
    }) { }

    void OnPlayerLogin(Player* player) override
    {
        if (!Cfg.enabled)
            return;
        PlayerState* st = GetState(player);
        st->stamina = Cfg.staminaMax;
        if (Cfg.announce)
            ChatHandler(player->GetSession()).SendSysMessage("This realm uses |cff4fc3f7Action Combat|r. Install the ActionCombat addon and set your keybinds (Esc > Key Bindings > ActionCombat).");
    }

    // Addon messages arrive here as a whisper to yourself: "ACM\t<command>"
    bool OnPlayerCanUseChat(Player* player, uint32 /*type*/, uint32 lang, std::string& msg, Player* receiver) override
    {
        if (lang != LANG_ADDON || receiver != player)
            return true;

        std::string const prefix = std::string(ADDON_PREFIX) + "\t";
        if (msg.compare(0, prefix.size(), prefix) != 0)
            return true;

        if (!Cfg.enabled)
            return false;

        PlayerState* st = GetState(player);
        std::lock_guard<std::mutex> lock(st->queueLock);
        if (st->queue.size() < 16)                      // flood guard
            st->queue.push_back(msg.substr(prefix.size()));
        return false;                                   // swallow it, don't echo the whisper
    }

    void OnPlayerUpdate(Player* player, uint32 diff) override
    {
        if (!Cfg.enabled)
            return;

        PlayerState* st = GetState(player);
        uint32 now = getMSTime();

        std::deque<std::string> pending;
        {
            std::lock_guard<std::mutex> lock(st->queueLock);
            pending.swap(st->queue);
        }
        for (std::string const& line : pending)
            Execute(player, st, line, now);

        if (!st->addonPresent)
            return;

        // Stamina regen
        if (st->stamina < Cfg.staminaMax && (!st->lastSpend || getMSTimeDiff(st->lastSpend, now) >= Cfg.staminaRegenDelay))
        {
            float rate = Cfg.staminaRegen * (st->guarding ? Cfg.guardRegenPct / 100.0f : 1.0f);
            st->stamina = std::min(Cfg.staminaMax, st->stamina + rate * float(diff) / 1000.0f);
        }

        // Throttled sync (every ~200ms, only when it changed)
        st->syncTimer += diff;
        if (st->syncTimer >= 200)
        {
            st->syncTimer = 0;
            if (int32(st->stamina) != st->lastSentStamina)
                SendStamina(player, st);
        }
    }
};

class ActionCombat_UnitScript : public UnitScript
{
public:
    ActionCombat_UnitScript() : UnitScript("ActionCombat_UnitScript", true, {
        UNITHOOK_MODIFY_MELEE_DAMAGE,
        UNITHOOK_MODIFY_SPELL_DAMAGE_TAKEN
    }) { }

    void ModifyMeleeDamage(Unit* target, Unit* attacker, uint32& damage) override
    {
        if (!Cfg.enabled || !target || !attacker)
            return;

        uint32 now = getMSTime();

        // --- Outgoing: player attacking
        if (Player* p = attacker->ToPlayer())
        {
            if (tl_swing && tl_swing->attacker == p->GetGUID())
            {
                float mult = tl_swing->damageMult;
                if (Creature* c = target->ToCreature())
                {
                    CreatureState* cs = GetState(c);
                    if (cs->riposteUntil && int32(now - cs->riposteUntil) < 0)
                    {
                        mult *= Cfg.riposteMult;
                        cs->riposteUntil = 0;
                        SendEvent(p, "RIPOSTE");
                    }
                    else
                        ApplyPoise(p, c, tl_swing->poiseDamage, now);
                }
                damage = uint32(float(damage) * mult);
            }
            else if (GetState(p)->addonPresent)
            {
                // Regular white swing: de-emphasize it so the action buttons matter.
                damage = uint32(float(damage) * Cfg.autoAttackPct / 100.0f);
            }
        }

        // --- Incoming: player being hit
        if (Player* victim = target->ToPlayer())
            DefendPlayer(victim, attacker, damage, true);
    }

    void ModifySpellDamageTaken(Unit* target, Unit* attacker, int32& damage, SpellInfo const* spellInfo) override
    {
        if (!Cfg.enabled || damage <= 0)
            return;

        Player* victim = target ? target->ToPlayer() : nullptr;
        if (!victim)
            return;

        // Physical "on next swing"/instant melee abilities count as melee for guarding/parrying.
        bool melee = spellInfo && spellInfo->DmgClass == SPELL_DAMAGE_CLASS_MELEE;
        uint32 dmg = uint32(damage);
        DefendPlayer(victim, attacker, dmg, melee);
        damage = int32(dmg);
    }
};

void AddSC_mod_action_combat()
{
    new ActionCombat_WorldScript();
    new ActionCombat_PlayerScript();
    new ActionCombat_UnitScript();
}
