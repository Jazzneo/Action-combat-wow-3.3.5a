#ifndef MOD_ACTION_COMBAT_H
#define MOD_ACTION_COMBAT_H

#include "DataMap.h"
#include "Define.h"

#include <deque>
#include <mutex>
#include <string>

class Player;
class Creature;

namespace ActionCombat
{
    constexpr char const* ADDON_PREFIX = "ACM";

    struct Config
    {
        bool   enabled = true;
        bool   announce = true;

        float  staminaMax = 100.0f;
        float  staminaRegen = 35.0f;
        uint32 staminaRegenDelay = 900;
        float  guardRegenPct = 40.0f;

        float  dodgeCost = 25.0f;
        uint32 dodgeCooldown = 450;
        uint32 dodgeIFrames = 400;
        float  dodgeSpeedXY = 16.0f;
        float  dodgeSpeedZ = 3.0f;
        float  backstepSpeedXY = 10.0f;
        uint32 backstepIFrames = 250;

        float  lightCost = 12.0f;
        uint32 lightCooldown = 550;
        float  lightRange = 5.0f;
        float  lightArcDeg = 100.0f;
        float  lightFinisherArcDeg = 200.0f;
        float  lightPoise = 12.0f;
        uint32 comboWindow = 1100;
        float  comboMult[3] = { 1.0f, 1.15f, 1.5f };

        float  heavyCost = 30.0f;
        uint32 heavyMinCharge = 350;
        uint32 heavyMaxCharge = 1500;
        uint32 heavyCooldown = 900;
        float  heavyRange = 6.0f;
        float  heavyArcDeg = 140.0f;
        float  heavyMinMult = 1.6f;
        float  heavyMaxMult = 2.8f;
        float  heavyPoise = 40.0f;

        uint32 maxTargets = 5;
        float  autoAttackPct = 30.0f;

        float  guardReductionPct = 70.0f;
        float  guardStaminaPerDmgPct = 2.0f;
        float  guardMinStaminaHit = 8.0f;
        bool   guardSpellsToo = false;
        uint32 parryWindow = 220;
        float  parryPoise = 100.0f;

        uint32 staggerSpell = 56;
        float  poiseNormal = 40.0f;
        float  poiseElite = 120.0f;
        float  poiseBoss = 0.0f;
        uint32 poiseRegenDelay = 4000;
        uint32 riposteWindow = 3000;
        float  riposteMult = 2.5f;
    };

    extern Config Cfg;

    struct PlayerState : public DataMap::Base
    {
        float  stamina = 100.0f;
        int32  lastSentStamina = -1;
        uint32 lastSpend = 0;
        uint32 syncTimer = 0;
        bool   addonPresent = false;

        uint32 iframesUntil = 0;
        uint32 nextDodgeAt = 0;

        uint8  comboIndex = 0;
        uint32 lastLight = 0;
        uint32 nextLightAt = 0;

        uint32 heavyChargeStart = 0;
        uint32 nextHeavyAt = 0;

        bool   guarding = false;
        uint32 guardStart = 0;
        bool   parryUsed = false;

        std::mutex queueLock;
        std::deque<std::string> queue;
    };

    struct CreatureState : public DataMap::Base
    {
        float  poise = 0.0f;
        uint32 lastPoiseHit = 0;
        uint32 riposteUntil = 0;
    };

    void LoadConfig();
}

#endif
